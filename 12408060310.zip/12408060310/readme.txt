学号：12408060310
班级：124030301
姓名：张三
参数：S=10，A=1，B=2，C=0
Stock=5，Buy=2
N=1610，Q=100
运行环境：mongosh、Redis‑py，Redis集群三主三从
依赖：python redis库
执行说明：
task1、task2：mongosh执行main.js，输出保存至result.txt
task3：复制redis_cmd.txt内命令到Redis网页控制台执行，结果截图保存
task4：python task4.py运行，输出复制保存到result.txt
注意：代码中无数据库账号密码凭据