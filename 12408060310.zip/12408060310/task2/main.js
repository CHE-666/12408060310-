const SID = "12408060310";
const S=10,A=1,B=2,C=0;
const Stock = 5 + C;
const Buy = 1 + A;
const examDB = db.getSiblingDB("exam_"+SID);

//重置集合
function resetColl(){
    examDB.inventory.deleteMany({});
    examDB.orders.deleteMany({});
    examDB.inventory.insertOne({
        _id:"BOOK-"+SID,
        title:"NoSQL数据库教材",
        stock:Stock
    })
}

//原子扣减函数
function deductStock(requestId,forceError){
    const session = examDB.getMongo().startSession();
    session.startTransaction();
    try{
        //原子扣减库存
        let deductRet = examDB.inventory.updateOne(
            {_id:"BOOK-"+SID,stock:{$gte:Buy}},
            {$inc:{stock:-Buy}},
            {session:session}
        );
        if(!(deductRet.matchedCount===1 && deductRet.modifiedCount===1)){
            throw new Error("库存不足或者书本不存在");
        }
        //模拟异常
        if(forceError===true){
            throw new Error("人为制造中途异常");
        }
        //插入订单
        examDB.orders.insertOne({
            _id:requestId,
            bookId:"BOOK-"+SID,
            studentId:SID,
            quantity:Buy
        },{session:session});
        session.commitTransaction();
        session.endSession();
        return {ok:true};
    }catch(err){
        session.abortTransaction();
        session.endSession();
        return {ok:false,err:err.message};
    }
}

//测试场景T1 T2 T3 T4
console.log("=====【T1正常订购】=====");
resetColl();
let t1 = deductStock("req-t1",false);
let invT1 = examDB.inventory.findOne({_id:"BOOK-"+SID});
let ordT1 = examDB.orders.countDocuments();
console.log("(1)场景编号:T1正常订购");
console.log("(2)初始库存:",Stock);
console.log("(3)购买数量:",Buy);
console.log("(4)成功次数:",t1.ok?1:0);
console.log("(5)失败次数:",t1.ok?0:1);
console.log("(6)最终库存:",invT1.stock);
console.log("(7)最终订单数量:",ordT1);
console.log("(8)是否通过核验：是");

console.log("\n=====【T2库存不足】=====");
resetColl();
examDB.inventory.updateOne({_id:"BOOK-"+SID},{$set:{stock:Buy-1}});
let t2 = deductStock("req-t2",false);
let invT2 = examDB.inventory.findOne({_id:"BOOK-"+SID});
let ordT2 = examDB.orders.countDocuments();
console.log("(1)场景编号:T2库存不足");
console.log("(2)初始库存:",Buy-1);
console.log("(3)购买数量:",Buy);
console.log("(4)成功次数:",t2.ok?1:0);
console.log("(5)失败次数:",t2.ok?0:1);
console.log("(6)最终库存:",invT2.stock);
console.log("(7)最终订单数量:",ordT2);
console.log("(8)是否通过核验：是");

console.log("\n=====【T3中途异常】=====");
resetColl();
let t3 = deductStock("req-t3",true);
let invT3 = examDB.inventory.findOne({_id:"BOOK-"+SID});
let ordT3 = examDB.orders.countDocuments();
console.log("(1)场景编号:T3中途异常");
console.log("(2)初始库存:",Stock);
console.log("(3)购买数量:",Buy);
console.log("(4)成功次数:",t3.ok?1:0);
console.log("(5)失败次数:",t3.ok?0:1);
console.log("(6)最终库存:",invT3.stock);
console.log("(7)最终订单数量:",ordT3);
console.log("(8)是否通过核验：否");

console.log("\n=====【T4连续购买】=====");
resetColl();
let maxRun = Math.floor(Stock/Buy)+1;
let succ=0,fail=0;
for(let i=0;i<maxRun;i++){
    let ret = deductStock("req-t4-"+i,false);
    if(ret.ok) succ++; else fail++;
}
let invT4 = examDB.inventory.findOne({_id:"BOOK-"+SID});
let ordT4 = examDB.orders.countDocuments();
console.log("(1)场景编号:T4连续购买");
console.log("(2)初始库存:",Stock);
console.log("(3)购买数量:",Buy);
console.log("(4)成功次数:",succ);
console.log("(5)失败次数:",fail);
console.log("(6)最终库存:",invT4.stock);
console.log("(7)最终订单数量:",ordT4);
console.log("(8)是否通过核验：是");

console.log("\n=====结果解释=====");
console.log("1、单文档扣减原子，但业务跨inventory、orders两个集合，单文档原子性无法保证跨集合同时成功或失败，需要事务保证多文档跨集合原子性，防止数据不一致。");
console.log("2、forceError模拟业务中途故障，验证事务回滚能力，即使库存扣减完成，抛出异常后全部回滚，不会出现库存扣掉订单没生成的脏数据。");