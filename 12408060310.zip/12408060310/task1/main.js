const SID = "12408060310";
const S = 10;
const A = 1;
const examDB = db.getSiblingDB("exam_" + SID);

//初始化数据
examDB.courses.deleteMany({});
examDB.courses.insertMany([
  {
    _id: "COURSE-" + SID + "-01",
    title: "NoSQL数据库",
    teacher: "张老师",
    status: "OPEN",
    chapters: [
      { chapterId: "CH01", title: "MongoDB基础", hours: 2 },
      { chapterId: "CH02", title: "Redis基础", hours: 2 }
    ]
  },
  {
    _id: "COURSE-" + SID + "-02",
    title: "数据库原理",
    teacher: "张老师",
    status: "CLOSED",
    chapters: [
      { chapterId: "CH01", title: "关系模型", hours: 2 }
    ]
  },
  {
    _id: "COURSE-" + SID + "-03",
    title: "机器学习",
    teacher: "李老师",
    status: "OPEN",
    chapters: [
      { chapterId: "CH01", title: "分类", hours: 2 },
      { chapterId: "CH02", title: "聚类", hours: 2 }
    ]
  }
]);

//1.查询张老师 OPEN课程，输出课程编号、名称、章节数量
console.log("=====第1小题查询结果=====");
let res1 = examDB.courses.aggregate([
  {$match:{teacher:"张老师",status:"OPEN"}},
  {$project:{_id:1,title:1,chapterCount:{$size:"$chapters"}}}
]);
res1.forEach(doc=>printjson(doc));

//2.修改CH02标题 Redis基础与应用‑10
console.log("\n=====第2小题更新CH02=====");
let res2 = examDB.courses.updateOne(
  {_id:"COURSE-"+SID+"-01","chapters.chapterId":"CH02"},
  {$set:{"chapters.$.title":"Redis基础与应用-"+S}}
);
printjson(res2);
printjson(examDB.courses.findOne({_id:"COURSE-"+SID+"-01"}));

//3.增加CH03章节 hours=2+A=3，执行两次防止重复
console.log("\n=====第3小题新增CH03，执行第一次=====");
let res3_1 = examDB.courses.updateOne(
  {_id:"COURSE-"+SID+"-01","chapters.chapterId":{$ne:"CH03"}},
  {$push:{chapters:{chapterId:"CH03",title:"Redis高级操作",hours:2+A}}}
);
printjson(res3_1);

console.log("\n=====第3小题新增CH03，执行第二次=====");
let res3_2 = examDB.courses.updateOne(
  {_id:"COURSE-"+SID+"-01","chapters.chapterId":{$ne:"CH03"}},
  {$push:{chapters:{chapterId:"CH03",title:"Redis高级操作",hours:2+A}}}
);
printjson(res3_2);

//4核验
console.log("\n=====第4小题核验=====");
let finalDoc = examDB.courses.findOne({_id:"COURSE-"+SID+"-01"});
printjson(finalDoc);
console.log("CH02标题：",finalDoc.chapters[1].title);
let ch03Arr = finalDoc.chapters.filter(x=>x.chapterId==="CH03");
console.log("CH03数量：",ch03Arr.length);
console.log("章节总数：",finalDoc.chapters.length);
console.log("teacher原值：",finalDoc.teacher);
console.log("status原值：",finalDoc.status);