import redis
import time

SID = "12408060310"
N = 1610
Q = 100

#连接，根据老师环境修改host，不要写密码
r = redis.Redis(host="127.0.0.1", port=6379, decode_responses=True)

#方案甲 逐条写入
start_seq = time.time()
for i in range(1, N + 1):
    key = f"exam:{SID}:seq:{i}"
    val = f"value-{SID}-{i}"
    r.set(key, val)
end_seq = time.time()
time_ms_seq = round((end_seq - start_seq)*1000)

#方案乙 pipeline非事务 transaction=False
start_pipe = time.time()
batch = []
batch_count = 0
last_batch_size = 0
for i in range(1, N +1):
    key = f"exam:{SID}:pipe:{i}"
    val = f"value-{SID}-{i}"
    batch.append(("set", key, val))
    if len(batch)>=Q:
        pipe = r.pipeline(transaction=False)
        for cmd in batch:
            pipe.execute_command(*cmd)
        pipe.execute()
        batch_count += 1
        batch.clear()
if batch:
    last_batch_size = len(batch)
    pipe = r.pipeline(transaction=False)
    for cmd in batch:
        pipe.execute_command(*cmd)
    pipe.execute()
    batch_count += 1
end_pipe = time.time()
time_ms_pipe = round((end_pipe-start_pipe)*1000)

#校验
ok_seq = 0
ok_pipe =0
for i in range(1,N+1):
    if r.get(f"exam:{SID}:seq:{i}") == f"value-{SID}-{i}":
        ok_seq +=1
    if r.get(f"exam:{SID}:pipe:{i}") == f"value-{SID}-{i}":
        ok_pipe +=1

#输出结果，复制保存到result.txt
print(f"命令总数：{N}")
print(f"Pipeline批次数：{batch_count}")
print(f"最后一批数量：{last_batch_size}")
print(f"方案甲耗时(ms)：{time_ms_seq}")
print(f"方案乙耗时(ms)：{time_ms_pipe}")
print(f"逐条写入校验成功 {ok_seq}/{N}")
print(f"Pipeline写入校验成功 {ok_pipe}/{N}")